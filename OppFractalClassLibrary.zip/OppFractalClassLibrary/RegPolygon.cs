﻿using System;
using System.Drawing;

namespace OppFractalClassLibrary
{
    //дъщерен клас на класа Figure-правилни многоъгълници
    public class RegPolygon : Figure
    {
        public Color Color { get; set; }
        public bool Solid { get; set; }

        private int width;
        private int dim;
        public float X, XX, Y, YY, Width;


       // double h;
      //  double a;
       // double R;

        float h;
        float a;
        float R;

        public RegPolygon()
        {

        }


        public RegPolygon(int newx, int newy, int newwidth, int newdim) : base(newx, newy)
        {

            setWidth(newwidth);
            setDim(newdim);
            a = (float)width;
            h = (float)(a / Math.Tan(180 / dim));
            R = (float)(a /2* Math.Sin(180 / dim));
            X = (float)getX();
            Y = (float)getY();
            Width = (float)getWidth();
        }
        //newwidt-размер на страната, newdim- брой страни;
        public int getWidth() { return width; }
        public int getDim() { return dim; }
        public void setWidth(int newwidth) { width = newwidth; }
        public void setDim(int newdim) { dim = newdim; }

//предефиниране на абстарактните функлии
        public override double Area() => a * h;
        public override int Perimetar() => width * dim;





        
      //  public override void DrawFigures(float X, float Y, int dim, Graphics _graph, string colorone)
            public override void DrawFigures( Graphics _graph, string colorone)
        {
            PointF[] points = new PointF[dim];
         


            XX = X;
            YY = Y;
            for (int i = 0; i < dim; i++)
            {

                points[i] = new PointF(XX, YY);
             
                if (dim == 4)
                {
                    points[0] = new PointF(XX, YY);
                    points[1] = new PointF(XX+a, YY);
                    points[2] = new PointF(XX+a, YY+a);
                    points[3] = new PointF(XX, YY+a);
                  
                }
                else
                {
                    XX = X + a / 4 - (float)(R * Math.Sin(i * 2 * Math.PI / dim));

                    YY = Y - R + (float)(R * Math.Cos(i * 2 * Math.PI / dim));


                    points[i] = new PointF(XX, YY);
                }
            }

          

            SolidBrush newBrush = new SolidBrush(Color.FromName(colorone));
            _graph.FillPolygon(newBrush,points);

        }

        //вируални функции за четраене на фигури
        //предефинират се в следващите от иерархията класове:Triangle_new, Carpet_new, Pentagon_new
        public virtual void DrawFigure(PointF top, PointF left, PointF right, Graphics _graph, int rot, string colorone)
        {
            Point[] points = new Point[dim];


            
        }

        public virtual void DrawFigure_Pentagon(int level, PointF top, PointF left1, PointF left, PointF right, PointF right1, Graphics _graph, int rot, string colorone, string colortow)
        {
            Point[] point = new Point[dim];
        }
        public virtual void DrawFigure__Carpet(RectangleF carpet, Graphics _gr, int rot, string colorone)
        {
            RectangleF _carpet = new RectangleF(0,0,100, 100 );
        }
    }   

   
} 
